This project was done to detect coins in a variety of situations. 

Part 1 is focused on color images as well as finding suitable means to detect circles in an image.

Part 2 applies what is learned in Part 1 to 2 further image sets of increasing difficulty. 

The word doc in each part explains my findings for the images and methods.

The word doc in this section, part 3, summarizes my findings as well as draws a few conclusions from each other two parts. 